var altura = parseInt(prompt("Ingresa la altura del Rectangulo"))
var base = parseInt(prompt("Ingresa la base del Rectangulo"))

for(i=0; i<=altura; i++){
    for(j=0; j<=base; j++){
        document.write("*")
    }
   document.write("<br>")
   
}
