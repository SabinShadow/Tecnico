var numeroIngresado = parseInt(prompt("Ingresa un Numero"))
var i = 0 

for(i=0; i<=numeroIngresado; i++){
    document.write(2 * numeroIngresado + 3).toString()
}