var salir = parseInt(prompt("Ingresa un numero"))

while(salir !== 0){
    salir = parseInt(prompt("Ingresa un numero"))
    document.write(salir + "<br>"+ " ")
}
