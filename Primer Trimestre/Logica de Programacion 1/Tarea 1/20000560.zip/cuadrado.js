var numero=prompt("Ingresa un number")

var numeroingresado=parseInt(numero)
document.write(Math.pow(numeroingresado,2))

document.write(numeroingresado ** 3)
//no encontre como hacer el salto de linea en javascript