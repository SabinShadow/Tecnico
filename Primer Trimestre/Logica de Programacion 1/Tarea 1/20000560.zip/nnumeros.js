var numero = prompt("Escribe un Numero")
var numeroIngresado = parseInt(numero)


for ( var i=numeroIngresado; i>=1; i--){
 var desglose = parseInt(document.write(i + " "))
}



//no logre que se sumaran los datos de del for 