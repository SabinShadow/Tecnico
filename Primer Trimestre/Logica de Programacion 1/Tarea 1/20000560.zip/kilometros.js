var kilometros=prompt("Escribe los kilometros a convertir a metros")

var numeroIngresado=parseInt(kilometros)
document.write(numeroIngresado*1000 +" Este es el resultado en metros")
