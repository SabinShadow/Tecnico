var nombre=prompt("Escribe tu nombre");

document.write(nombre);
