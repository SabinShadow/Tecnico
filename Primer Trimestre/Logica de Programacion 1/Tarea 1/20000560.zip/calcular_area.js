var pi = Math.PI
var radio = parseFloat(prompt("Diametro del Circulo a calcular en metros"))
var area = pi * Math.pow(radio,2)

document.write("El area del circulo en metros es " + area)

//intente hacerlo con una funcion pero no pude