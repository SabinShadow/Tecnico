var numero = parseInt(prompt("Ingresa un numero"))


    if (numero / numero === 0 & numero % 100 === 0){
        document.write(numero + " Es Primo")
    }
     else   {
        document.write(numero + " No es Primo")
    }


// no logre que marcara la diferencia entre primo y no primo